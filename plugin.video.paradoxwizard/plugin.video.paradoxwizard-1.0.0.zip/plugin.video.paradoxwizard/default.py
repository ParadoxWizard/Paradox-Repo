import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, base64, sys, xbmcvfs, atexit
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import json
import plugintools
from ConfigParser import SafeConfigParser
from addon.common.addon import Addon
from addon.common.net import Net




AddonID             = 'plugin.video.paradoxwizard'
ADDON               = xbmcaddon.Addon(id=AddonID)
VERSION             = "1.0.0"
ADDONPATH           = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID))
AddonTitle          = "Paradox Wizard"
USER_AGENT          = 'Kodi/Paradox Wizard'
U                   = ADDON.getSetting('username')
P                   = ADDON.getSetting('password')

dialog              = xbmcgui.Dialog()
net                 = Net()

BASEURL             = "http://paradoxwizard.co.uk/"
CHECKURL            = BASEURL + "json/"

ART                 = xbmc.translatePath(os.path.join('special://home/addons/' + AddonID + '/resources/art/'))
DBPATH              = xbmc.translatePath('special://database')
TNPATH              = xbmc.translatePath('special://thumbnails');

EXCLUDES            = ['plugin.video.paradoxwizard','script.module.addon.common','repository.paradox']

FANART              = ART+'fanart.png'
ICON                = ART+'icon.png'

#set some default icons
INSTALLICON         = ICON
MAINTAINANCEICON    = ICON
CONTACTICON         = ICON
CLEARCACHEICON      = ICON
FRESHSTARTICON      = ICON
PURGEICON           = ICON




def DoE(e): xbmc.executebuiltin(e)
def DoAW(e): xbmc.executebuiltin("ActivateWindow(%s)" % str(e))
def DoRW(e): xbmc.executebuiltin("ReplaceWindow(%s)" % str(e))
def DoRA(e): xbmc.executebuiltin("RunAddon(%s)" % str(e))
def DoRA2(e,e2="1",e3=""): xbmc.executebuiltin('RunAddon(%s,"%s","%s")' % (str(e),str(e2),e3)); 
def DoA(a): xbmc.executebuiltin("Action(%s)" % str(a))
def DoCM(a): xbmc.executebuiltin("Control.Message(windowid=%s)" % (str(a)))
def DoSC(a): xbmc.executebuiltin("SendClick(%s)" % (str(a)))
def DoSC2(a,Id): xbmc.executebuiltin("SendClick(%s,%s)" % (str(a),str(Id)))
def DoStopScript(e): xbmc.executebuiltin("StopScript(%s)" % str(e))
def DoTD(): xbmc.executebuiltin("ToggleDebug")
def exit_handler():
    print 'My application is ending!'
    
atexit.register(exit_handler)

def SETUP():
    global INSTALLICON,MAINTAINANCEICON,CONTACTICON,CLEARCACHEICON,FRESHSTARTICON,PURGEICON
    # See if we can update the logos used
    logopath = BASEURL + "icon/paradox-wizard-icons.cfg"
    path = xbmc.translatePath(os.path.join('special://home/addons','packages/'))
    downloader.download(logopath, path + "/paradox-wizard-icons.cfg")
    icons = SafeConfigParser()
    icons.read(path + "/paradox-wizard-icons.cfg")
    INSTALLICON         = str(icons.get('icons', 'installicon'))
    MAINTAINANCEICON    = str(icons.get('icons', 'maintainanceicon'))
    CONTACTICON         = str(icons.get('icons', 'contacticon'))
    CLEARCACHEICON      = str(icons.get('icons', 'clearcacheicon'))
    FRESHSTARTICON      = str(icons.get('icons', 'freshstarticon'))
    PURGEICON           = str(icons.get('icons', 'purgeicon'))
    FANART              = str(icons.get('icons', 'fanart'))
    INDEX()

def INDEX():

    addDir('Install Paradox',BASEURL,2,INSTALLICON,FANART,'')
    addDir('Maintenance',BASEURL,3,MAINTAINANCEICON,FANART,'')
    addDir('Contact',BASEURL,8,CONTACTICON,FANART,'')
    setView('movies', 'MAIN')

def BUILDMENU():

    data = OPEN_URL(CHECKURL + "curr_builds.php")
    parsed = json.loads(data)

    for build in parsed:
        addDir(build['bfriendlyname'] + ' - ' + build['bversion'],build['bslug'],5,build['bicon'],FANART,'')
        setView('movies', 'MAIN')

def MAINTENANCE():
    addDir('Clear Cache','url',4,CLEARCACHEICON,FANART,'')
    addDir('Fresh Start','url',6,FRESHSTARTICON,FANART,'')
    addDir('Purge Packages','url',7,PURGEICON,FANART,'')
    setView('movies', 'MAIN')



#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

def facebook():
    TextBoxes(AddonTitle,'[COLOR=orange]Welcome to Paradox[/COLOR][CR][CR]')        
    

#################################
####BUILD INSTALL################
#################################

def WIZARD(name,url,description):

    xbmc.executebuiltin( "ActivateWindow(busydialog)" )

    # Check the username and password set in the wizard
    data = OPEN_URL(CHECKURL + "build.php?" + "u=" + U + "&p=" + P + "&b=" + url)
    parsed = json.loads(data)
    build = str(parsed.get('build'))
    version = str(parsed.get('version'))

    # See if we have a version file
    versionpath = xbmc.translatePath(os.path.join('special://','home'))
    versionfile = versionpath + 'version.txt'
    versionfileexists = os.path.isfile(versionfile)
    parser = SafeConfigParser()
    parser.read(versionfile)

    # Check the version of the build against the latest available version
    if versionfileexists and parser.get('versioninfo', 'version') == parsed.get('version') and parser.get('versioninfo', 'build') == parsed.get('title'):
        dialog = xbmcgui.Dialog()
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        dialog.ok(AddonTitle, "You already have the most recent version","", str(parser.get('versioninfo', 'build')) + " " + str(parser.get('versioninfo', 'version')))
    else:

        path = xbmc.translatePath(os.path.join('special://home/addons','packages/'))
        fileexists = os.path.isfile(path+url+version+'.zip')
        existingfile = os.path.join(path+url+version+'.zip')

        if fileexists:
            lib = existingfile
            dp = xbmcgui.DialogProgress()
            xbmc.executebuiltin( "Dialog.Close(busydialog)" )
            addonfolder = xbmc.translatePath(os.path.join('special://','home'))
            time.sleep(2)
            dp.create(AddonTitle,"Extracting "+ name, "Please Wait...")
            extract.all(lib,addonfolder,dp)
            ADDON.setSetting(id="username", value="")
            ADDON.setSetting(id="password", value="")
            dialog = xbmcgui.Dialog()
            dialog.ok(AddonTitle, name + " has been installed from your existing packages")
            dialog.ok(AddonTitle, " ", "To save changes you now need to force close Kodi, Press OK to force close Kodi")
            killxbmc()

        else:

            if parsed.get('auth'):
                rid = parsed.get('id')
                dp = xbmcgui.DialogProgress()
                xbmc.executebuiltin( "Dialog.Close(busydialog)" )

                whatami = platform()
                if whatami == "windows":
                    FRESHSTARTBUILD(params)

                dp.create(AddonTitle,"Downloading "+ parsed.get('title')+ " - " + parsed.get('version'), "Please Wait...")
                lib = existingfile

                # added to remove any partially downloaded files
                try:
                    downloader.download(parsed.get('url'), lib, dp)
                except:
                    os.remove(lib)
                    return

                addonfolder = xbmc.translatePath(os.path.join('special://','home'))
                time.sleep(2)
                dp.update(0,"", "Extracting "+ parsed.get('title') +" Zip","Please Wait...")
                extract.all(lib,addonfolder,dp)
                ADDON.setSetting(id="username", value="")
                ADDON.setSetting(id="password", value="")
                successdata = OPEN_URL(CHECKURL + "build.php?" + "r=" + str(rid) + "&b=" + url)
                suceess = json.loads(successdata)
                dialog = xbmcgui.Dialog()
                dialog.ok(AddonTitle, suceess.get('mtit'),"", suceess.get('mmsg'))
                dialog.ok(AddonTitle, " ", "To save changes you now need to force close Kodi, Press OK to force close Kodi")
                killxbmc()

            else:
                xbmc.executebuiltin( "Dialog.Close(busydialog)" )
                dialog = xbmcgui.Dialog()
                dialog.ok(AddonTitle, parsed.get('etit'),"", parsed.get('emsg'))




################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok(AddonTitle, "Packages Successfuly Removed", "[COLOR yellow]Brought To You By TheBlackBox Wizard[/COLOR]")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "Sorry we were not able to remove Package Files", "[COLOR yellow]Brought To You By TheBlackBox Wizard[/COLOR]")
    


#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
    
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                

    dialog = xbmcgui.Dialog()
    dialog.ok(AddonTitle, " All Cache Files Removed", "[COLOR yellow]Brought To You By TheBlackBox Wizard[/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
    choice = xbmcgui.Dialog().yesno('Force Close Kodi', 'You are about to close Kodi', 'Would you like to continue?', nolabel='No, Cancel',yeslabel='Yes, Close')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=yellow][B]TO COMPLETE THEBLACKBOX UPDATE[/COLOR][/B]", "Press the HOME button on your remote and [COLOR=red][B]FORCE STOP[/COLOR][/B] KODI via the Manage Installed Applications menu in settings on your Amazon home page then re-launch KODI")
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit cleanly via the menu.","Use task manager and NOT ALT F4")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=lime]DO NOT[/COLOR] exit via the menu.","iOS detected.  Press and hold both the Sleep/Wake and Home button for at least 10 seconds, until you see the Apple logo.")    

##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Do you wish to restore your","Kodi configuration to default settings?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete","click OK to begin clean installation")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete","click OK to begin clean installation")
        except: plugintools.message(AddonTitle,"Problem found","Your settings has not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Now Exit Kodi",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","has not been changed"); plugintools.add_item(action="",title="Done",folder=False)


def FRESHSTARTBUILD(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"Would you like this build to be installed from a fresh start ?")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    try: os.remove(os.path.join(root,name))
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(AddonTitle,"The process is complete","Click OK to begin clean installation")
            else: plugintools.log("freshstart.main_list User files partially removed"); plugintools.message(AddonTitle,"The process is complete","Click OK to begin clean installation")
        except: plugintools.message(AddonTitle,"Problem found","Your settings have not been changed"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Now Exit Kodi",folder=False)
    else: plugintools.message(AddonTitle,"Your settings","have not been changed"); plugintools.add_item(action="",title="Done",folder=False)


def fixBadZipfile(zipFile):  
    f = open(zipFile, 'r+b')  
    data = f.read()  
    pos = data.find('\x50\x4b\x05\x06') # End of central directory signature  
    if (pos > 0):  
        print "Trancating file at location " + str(pos + 22)+ "."  
        f.seek(pos + 22)   # size of 'ZIP end of central directory record' 
        f.truncate()  
        f.close()  
    else:
        pass
        # raise error, file is truncated  
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        SETUP()

elif mode==2:
        BUILDMENU()

elif mode==3:
        MAINTENANCE()
        
elif mode==4:
        deletecachefiles(url)
        
elif mode==5:
        WIZARD(name,url,description)

elif mode==6:        
    FRESHSTART(params)
    
elif mode==7:
       DeletePackages(url)

elif mode==8:
       facebook()
       
elif mode==9:
       donation()

elif mode==11:
        DELETEIVUEDB()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
